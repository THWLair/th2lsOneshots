ESP
Hola si vas a usar el script porfavor dame creditos
Sobre el script este no es igual ni perfecto 
a comparacion de la pantalla de resultados 
orignal por lo que si deseas modificar y mejorar 
este puedes hacerlo solo que recuerda dejar 
creditos :) 
ENG
Hello, if you are going to use the script, please give me credits
Regarding the script, this is not the same or perfect
compared to the results screen
original so if you want to modify and improve
you can do this just remember to leave
credits :)
